import sys
from setuptools import setup
setup(
    name = "lectordeplacas",
    version = "0.1",
    packages=["lectordeplacas"],
    author="Embebidos",
    author_email = "alex@example.com",
    description = "lectordeplacas con open CV",
    license = "MIT",
    keywords= "example",
    url = "",
)
